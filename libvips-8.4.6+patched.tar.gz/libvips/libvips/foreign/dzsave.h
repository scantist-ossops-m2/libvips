void shrink_region_uncoded( VipsRegion *from, VipsRegion *to, 
	VipsRect *target );

